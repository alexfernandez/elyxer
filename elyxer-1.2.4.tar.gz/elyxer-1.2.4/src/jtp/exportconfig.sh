#!/bin/bash
# Alex 2010-03-14: export configuration for JavaToPy

./exportconfig.py --cfg conf/jtp.cfg --py conf/javatopyconf.py py

